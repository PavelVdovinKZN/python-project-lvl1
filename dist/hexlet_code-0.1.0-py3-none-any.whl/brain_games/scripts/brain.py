import prompt


def welcome():
    return print("Welcome to the brain Games!")
